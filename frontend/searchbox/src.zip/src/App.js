import logo from './logo.svg';
import './App.css';
import Search from './component/Search';

function App() {
  return (
    <div className="App">
      <Search/>
    </div>
  );
}

export default App;
